<?php

$server = "localhost:3306";
$username = "c1923077c_qrcode";
$password = "Azerty%1234";
$database = "c1923077c_qrcode";
$connection = mysqli_connect($server, $username, $password);
$select_db = mysqli_select_db($connection, $database);
if(!$select_db) {
    echo 'Connection terminated';
}