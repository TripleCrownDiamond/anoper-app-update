<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générer QR Code à partir de données</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
       
        <div class="container text-center mt-4">
            <h2 class="text-success">QRCode généré avec succès.</h2>
        </div>
        <div class="container">
            <img class="mx-auto d-block" src="<?= $_GET['qrcodeurl'] ?>" alt=""/>
            <div class="text-center">
                <a href="<?= $_GET['qrcodeurl'] ?>" class="btn btn-success mb-3" download>Télécharger le QRCODE</a><br>
                <span>Pour générer un nouveau code QR </span><a href="index.html">Retour au formulaire</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>