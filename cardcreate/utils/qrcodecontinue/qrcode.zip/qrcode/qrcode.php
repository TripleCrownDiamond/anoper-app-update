<?php
require_once('databaseconnect.php');
require_once('phpqrcode/qrlib.php');
$path = 'images/';
$qrcode = $path.time(). ".png";
$qrimage = time(). ".png";

if(isset($_POST['submit'])) {
    $nom = htmlentities($_POST['nom']);
    $prenom = htmlentities($_POST['prenom']);
    $tel = htmlentities($_POST['tel']);
    $message = htmlentities($_POST['message']);

    $datas = array(
        "nom" => $nom,
        "prennom" => $prenom,
        "tel" => $tel,
        "message" => $message,
    );

    $query = mysqli_query($connection, "insert into data set nom = '$nom', prenom = '$prenom', tel = '$tel', message = '$message', qrcodepath = '$qrimage'");

    if($query) {
        ?>

            <script>
                alert("QRCode généré avec succès cliquez sur le boutton pour voir toute vos données.");
            </script>

        <?php

        $comma_separated = implode(",", $datas);

        QRcode :: png($comma_separated, $qrcode, 'H', 4, 4);

        header("Location: success.php?qrcodeurl=$qrcode");  

        //echo"<img src='" . $qrcode .  "'>";
    }else{
        ?>

            <script>
                alert("Erreur.");
            </script>

        <?php

    }
    //var_dump($datas);
}



